let produits = [];
let panier = [];

fetch('products.json')
  .then(res => res.json())
  .then(data => {
    produits = data;
    afficheCatalogue();
  });

function afficheCatalogue() {
  const c = document.getElementById('catalogue');
  produits.forEach(p => {
    const div = document.createElement('div');
    div.className = 'product';
    div.innerHTML = `
      <img src="${p.image}" alt="${p.nom}">
      <h3>${p.nom}</h3>
      <p>Prix : ${p.prix} FCFA</p>
      <button onclick="ajoutePanier(${p.id})">Ajouter</button>
    `;
    c.appendChild(div);
  });
}

function ajoutePanier(id) {
  const p = produits.find(x => x.id === id);
  panier.push(p);
  majPanier();
}

function majPanier() {
  const ul = document.getElementById('liste-panier');
  ul.innerHTML = '';
  let total = 0;
  panier.forEach((p,i) => {
    total += p.prix;
    const li = document.createElement('li');
    li.textContent = `${p.nom} - ${p.prix} FCFA`;
    ul.appendChild(li);
  });
  document.getElementById('total').textContent = total;
}

document.getElementById('vider-panier').addEventListener('click', () => {
  panier = [];
  majPanier();
});

document.getElementById('form-commande').addEventListener('submit', e => {
  e.preventDefault();
  if(panier.length === 0){
    alert('Ton panier est vide!');
    return;
  }
  const form = e.target;
  const cmd = {
    id: Date.now(),
    nom: form.nom.value,
    telephone: form.telephone.value,
    adresse: form.adresse.value,
    items: panier.map(p => ({id:p.id, nom:p.nom, prix:p.prix})),
    total: panier.reduce((sum,p) => sum + p.prix, 0)
  };
  console.log("Commande simulée :", cmd);
  document.getElementById('confirmation').textContent = 'Commande enregistrée!';
  panier = [];
  majPanier();
  form.reset();
});